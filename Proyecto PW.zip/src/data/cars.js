export const cars = [
  {
    id: 1,
    marca: 'Toyota',
    modelo: 'Corolla',
    anio: 2017,
    precioBase: 5200,
    imagen: 'https://puromotor.com/wp-content/uploads/2017/01/externa_5.jpeg',
    descripcion: 'Eficiente y confiable. Ideal para ciudad.'
  },
  {
    id: 2,
    marca: 'Honda',
    modelo: 'Civic',
    anio: 2018,
    precioBase: 6100,
    imagen: 'https://i0.wp.com/autosrodrod.com/wp-content/uploads/2019/06/1-5-1.jpg?fit=2649%2C1433&ssl=1',
    descripcion: 'Deportividad y consumo moderado.'
  },
  {
    id: 3,
    marca: 'Ford',
    modelo: 'Focus',
    anio: 2016,
    precioBase: 5400,
    imagen: 'https://acroadtrip.blob.core.windows.net/publicaciones-imagenes/Large/ford/focus/mx/RT_PU_9e49b9bebc3e41b38bdc2038bdc5a8cb.webp',
    descripcion: 'Buen agarre y espacio interior.'
  }
]

export const bidsByCarId = {
  1: [
    { user: 'Carlos', monto: 5250, fecha: '2025-09-03 10:21' },
    { user: 'Ana',    monto: 5350, fecha: '2025-09-03 10:45' },
  ],
  2: [
    { user: 'Luis',   monto: 6150, fecha: '2025-09-03 11:05' },
  ],
  3: []
}
