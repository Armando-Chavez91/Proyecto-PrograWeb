import { useState } from 'react'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()

    // Simulación de validación
    if (email === '' || password === '') {
      alert('⚠️ Por favor completa todos los campos')
      return
    }

    if (email === 'demo@carbid.com' && password === '1234') {
      alert('✅ Login exitoso (simulado)')
    } else {
      alert('❌ Credenciales incorrectas (simulado)')
    }

    setEmail('')
    setPassword('')
  }

  return (
    <main className="container">
      <h1>Iniciar sesión</h1>

      <form className="form" onSubmit={handleSubmit}>
        <input
          type="email"
          placeholder="Correo electrónico"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          type="password"
          placeholder="Contraseña"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <button className="btn" type="submit">Entrar</button>
      </form>

      <p className="muted" style={{ marginTop: '12px' }}>
        Usuario demo: <b>demo@carbid.com</b> / Contraseña: <b>1234</b>
      </p>
    </main>
  )
}
