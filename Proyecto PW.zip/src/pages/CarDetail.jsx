import { useParams, Link } from 'react-router-dom'
import { cars, bidsByCarId } from '../data/cars'
import { useMemo, useState } from 'react'

export default function CarDetail() {
  const { id } = useParams()
  const carId = Number(id)

  const car = useMemo(() => cars.find(c => c.id === carId), [carId])
  const [bids, setBids] = useState(bidsByCarId[carId] ?? [])

  if (!car) {
    return (
      <main className="container">
        <h2>Vehículo no encontrado</h2>
        <Link className="btn" to="/">← Volver al listado</Link>
      </main>
    )
  }

  const highest = bids.length ? Math.max(...bids.map(b => b.monto)) : car.precioBase

  const handleFakeBid = (e) => {
    e.preventDefault()
    const form = new FormData(e.currentTarget)
    const monto = Number(form.get('monto') || 0)
    const user  = String(form.get('user') || 'Usuario')

    if (monto <= highest) {
      alert(`La puja debe ser mayor a ${highest}`)
      return
    }
    const nueva = { user, monto, fecha: new Date().toISOString().slice(0,16).replace('T',' ') }
    setBids(prev => [nueva, ...prev])
    e.currentTarget.reset()
    alert('Puja registrada (simulada)')
  }

  return (
    <main className="container">
      <Link className="link-back" to="..">← Volver</Link>

      <div className="detail">
        <img src={car.imagen} alt={`${car.marca} ${car.modelo}`} />
        <div className="info">
          <h1>{car.marca} {car.modelo} <span className="year">({car.anio})</span></h1>
          <p className="desc">{car.descripcion}</p>
          <p className="price">Precio base: <b>${car.precioBase}</b></p>
          <p className="highest">Oferta más alta: <b>${highest}</b></p>

          <form className="bid-form" onSubmit={handleFakeBid}>
            <input name="user" type="text" placeholder="Tu nombre" required />
            <input name="monto" type="number" placeholder={`Tu puja (> ${highest})`} required />
            <button className="btn" type="submit">Pujar</button>
          </form>
        </div>
      </div>

      <section className="bids">
        <h2>Pujas recientes</h2>
        {bids.length === 0 && <p>Aún no hay pujas. ¡Sé el primero!</p>}
        <ul>
          {bids.map((b, i) => (
            <li key={i}>
              <b>${b.monto}</b> por {b.user} <span className="muted">({b.fecha})</span>
            </li>
          ))}
        </ul>
      </section>
    </main>
  )
}
