export default function Home() {
  return <h1>Página de Inicio - Subastas</h1>
}
    