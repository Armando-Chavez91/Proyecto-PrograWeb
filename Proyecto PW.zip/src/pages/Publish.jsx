export default function Publish() {
  return (
    <div>
      <h1>Publicar Vehículo</h1>
      <form>
        <input type="text" placeholder="Marca" />
        <input type="text" placeholder="Modelo" />
        <input type="number" placeholder="Año" />
        <input type="number" placeholder="Precio base" />
        <button type="submit">Guardar</button>
      </form>
    </div>
  )
}
