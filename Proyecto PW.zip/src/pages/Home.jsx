

import { Link } from 'react-router-dom'
import { cars } from '../data/cars'

export default function Home() {
  return (
    <main className="container">
      <h1>Subastas activas</h1>

      <div className="grid">
        {cars.map((car) => (
          <article className="card" key={car.id}>
            <img src={car.imagen} alt={`${car.marca} ${car.modelo}`} />
            <div className="card-body">
              <h3>{car.marca} {car.modelo} <span className="year">({car.anio})</span></h3>
              <p className="desc">{car.descripcion}</p>
              <p className="price">Precio base: <b>${car.precioBase}</b></p>
              <Link className="btn" to={`/car/${car.id}`}>Ver detalle</Link>
            </div>
          </article>
        ))}
      </div>
    </main>
  )
}


/*import { Link } from 'react-router-dom'

export default function Home() {
  return (
    <main style={{ padding: 16 }}>
      <h1>Página de Inicio - Subastas</h1>

      <ul style={{ listStyle: 'none', padding: 0 }}>
        {Array.isArray(cars) && cars.map((car) => (
          <li key={car.id} style={{ marginBottom: 12, border: '1px solid #eee', padding: 12 }}>
            <h3>{car.marca} {car.modelo}</h3>
            <p>Precio actual: ${car.precio}</p>
            <Link to={`/car/${car.id}`}>Ver detalle</Link>
          </li>
        ))}
      </ul>
    </main>
  )
}
*/