export default function History() {
  const history = [
    { car: 'Toyota Corolla 2017', estado: 'Ganada',   oferta: 5400 },
    { car: 'Honda Civic 2018',    estado: 'Perdida',  oferta: 6200 },
    { car: 'Ford Focus 2016',     estado: 'Perdida',  oferta: 5600 }
  ]

  return (
    <main className="container">
      <h1>Mi historial</h1>
      <table className="table">
        <thead>
          <tr><th>Vehículo</th><th>Estado</th><th>Mi oferta</th></tr>
        </thead>
        <tbody>
          {history.map((h, i) => (
            <tr key={i}>
              <td>{h.car}</td>
              <td><span className={`badge ${h.estado === 'Ganada' ? 'ok' : 'no'}`}>{h.estado}</span></td>
              <td>${h.oferta}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  )
}
