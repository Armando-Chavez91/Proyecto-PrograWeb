export default function NotFound() {
  return <h1> Página no encontrada</h1>
}
