import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import App from './App.jsx'
import Home from './pages/Home.jsx'
import CarDetail from './pages/CarDetail.jsx'
import History from './pages/History.jsx'
import Publish from './pages/Publish.jsx' 
import Login from './pages/Login.jsx'
import './style.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<App />}>
          <Route index element={<Home />} />
          <Route path="login" element={<Login />} />
          <Route path="/car/:id" element={<CarDetail />} />   
          <Route path="/history" element={<History />}/> 
          <Route path="/publish" element={<Publish />}/>
          <Route path="*" element={<h1>404</h1>} />
        </Route>
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
)
