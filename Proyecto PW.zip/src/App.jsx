import { Link, Outlet } from 'react-router-dom'

export default function App() {
  return (
    <div style={{ padding: 16 }}>
      <nav style={{ marginBottom: 12 }}>
        <Link to="/">Home</Link> | <Link to="/login">Login</Link> | <Link to="/NotFound">NotFound</Link> |
        <Link to="/Signup">Signup</Link> |  <Link to="/CarDetail">Detalle Auto</Link> | <Link to="/History">Record</Link> 
        | <Link to="/Publish">Publicar</Link>
      </nav>
      <Outlet />
    </div>
  )
}
